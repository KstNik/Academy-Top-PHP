<!-- Задание. Создайте скрипт, генерирующий случайный пароль для пользователя с заданной длиной и набором символов. -->
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Генератор паролей</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }
        input[type="checkbox"], input[type="number"] {
            margin-right: 10px;
        }
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .password-output {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            margin-bottom: 15px;
            text-align: center;
            background-color: #e8f0fe;
            color: #333;
            cursor: pointer;
        }
        button {
            width: 105%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            margin-top: 20px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .copy-message {
            color: #28a745;
            text-align: center;
            display: none;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Генератор паролей</h1>
    <form id="passwordForm">
        <label for="length">Длина пароля:</label>
        <input type="number" id="length" name="length" value="12" min="4" max="50" required>
        <label for="includeLetters">
            <input type="checkbox" id="includeLetters" name="includeLetters" checked> Включить буквы
        </label>
        <label for="includeNumbers">
            <input type="checkbox" id="includeNumbers" name="includeNumbers" checked> Включить цифры
        </label>
        <label for="includeSymbols">
            <input type="checkbox" id="includeSymbols" name="includeSymbols" checked> Включить символы
        </label>
        <button type="submit">Сгенерировать пароль</button>
        <input type="text" id="generatedPassword" class="password-output" onclick="copyPassword()" readonly>
        <div class="copy-message" id="copyMessage">Пароль скопирован в буфер обмена!</div>
    </form>
</div>
<script>
    document.getElementById('passwordForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const length = document.getElementById('length').value;
        const includeLetters = document.getElementById('includeLetters').checked;
        const includeNumbers = document.getElementById('includeNumbers').checked;
        const includeSymbols = document.getElementById('includeSymbols').checked;
        // AJAX запрос для генерации пароля
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'generate_password.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function () {
            if (xhr.status === 200) {
                document.getElementById('generatedPassword').value = xhr.responseText;
                document.getElementById('copyMessage').style.display = 'none';
            }
        };
        xhr.send('length=' + length + '&includeLetters=' + includeLetters + '&includeNumbers=' + includeNumbers + '&includeSymbols=' + includeSymbols);
    });
    // Функция для копирования пароля в буфер обмена
    function copyPassword() {
        const passwordField = document.getElementById('generatedPassword');
        passwordField.select();
        document.execCommand('copy');
        document.getElementById('copyMessage').style.display = 'block';
    }
</script>
</body>
</html>
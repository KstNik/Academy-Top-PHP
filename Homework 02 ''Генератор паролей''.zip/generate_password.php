<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы
    $length = isset($_POST['length']) ? (int)$_POST['length'] : 12;
    $includeLetters = isset($_POST['includeLetters']) && $_POST['includeLetters'] === 'true';
    $includeNumbers = isset($_POST['includeNumbers']) && $_POST['includeNumbers'] === 'true';
    $includeSymbols = isset($_POST['includeSymbols']) && $_POST['includeSymbols'] === 'true';
    // Функция для генерации пароля
    function generatePassword($length, $includeLetters, $includeNumbers, $includeSymbols) {
        $letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $numbers = '0123456789';
        $symbols = '!@#$%^&*()-_=+[]{}<>?,.';
        $characters = '';
        if ($includeLetters) $characters .= $letters;
        if ($includeNumbers) $characters .= $numbers;
        if ($includeSymbols) $characters .= $symbols;
        if (empty($characters)) return 'Ошибка: выберите хотя бы один набор символов.';
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $password .= $characters[random_int(0, strlen($characters) - 1)];
        }
        return $password;
    }
    // Возвращение сгенерированного пароля
    echo generatePassword($length, $includeLetters, $includeNumbers, $includeSymbols);
}
<!-- Задание. Создайте функцию, которая принимает три параметра: строку, слово для поиска, слово для замены.
Функция должна найти все вхождения слова для поиска и заменить его на слово для замены. По результатам работы функции должна измениться оригинальная строка, переданная в первом параметре. Из функции нужно вернуть количество замен.
Например:
Строка: cat runs to another cat
Слово для поиска: cat
Слово для замены: bull
Строка после изменения: bull runs to another bull
Возвращаемое значение: 2 -->
<?php
// Определение функции для замены слов
function replaceWordInString(&$str, $searchWord, $replaceWord) {
    $str = str_replace($searchWord, $replaceWord, $str, $count);
    return $count;
}
// Определение переменных для отображения значений после замены
$originalString = isset($_POST['originalString']) ? $_POST['originalString'] : '';
$searchWord = isset($_POST['searchWord']) ? $_POST['searchWord'] : '';
$replaceWord = isset($_POST['replaceWord']) ? $_POST['replaceWord'] : '';
$modifiedString = '';
$replaceCount = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $modifiedString = $originalString; // копирование исходной строки
    $replaceCount = replaceWordInString($modifiedString, $searchWord, $replaceWord);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Word Replace Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="text"]:read-only {
            background-color: #e9e9e9;
        }
        input[type="number"]:read-only {
            background-color: #e9e9e9;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <form method="post" action="">
            <div class="form-group">
                <label for="originalString">Исходная строка:</label>
                <input type="text" id="originalString" name="originalString" value="<?= htmlspecialchars($originalString) ?>" required>
            </div>
            <div class="form-group">
                <label for="searchWord">Слово для поиска:</label>
                <input type="text" id="searchWord" name="searchWord" value="<?= htmlspecialchars($searchWord) ?>" required>
            </div>
            <div class="form-group">
                <label for="replaceWord">Слово для замены:</label>
                <input type="text" id="replaceWord" name="replaceWord" value="<?= htmlspecialchars($replaceWord) ?>" required>
            </div>
            <div class="form-group">
                <label for="modifiedString">Изменённая строка:</label>
                <input type="text" id="modifiedString" value="<?= htmlspecialchars($modifiedString) ?>" readonly>
            </div>
            <div class="form-group">
                <label for="replaceCount">Количество замен:</label>
                <input type="number" id="replaceCount" value="<?= htmlspecialchars($replaceCount) ?>" readonly>
            </div>
            <button type="submit">Заменить</button>
        </form>
    </div>
</body>
</html>
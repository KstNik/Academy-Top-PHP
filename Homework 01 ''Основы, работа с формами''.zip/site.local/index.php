<!-- Задание.
Написать РНР скрипт, создающий на странице три текстовых поля. В эти поля пользователь должен заносить значения R, G и В цветовых компонент (в интервале 0-255). На странице также должна присутствовать кнопка Accept и тег span с каким-либо текстом внутри.
После нажатия на кнопку Accept, надо создать цвет на основе введенных пользователем значений R, G и В. Этим цветом залить фон тега span, а текст залить дополнительным цветом. -->
<?php
if (isset($_POST['r']) && isset($_POST['g']) && isset($_POST['b'])) {
    $r = $_POST['r'];
    $g = $_POST['g'];
    $b = $_POST['b'];
} else {
    $r = 255;
    $g = 255;
    $b = 255;
}
$bgColor = 'rgb(' . $r . ', ' . $g . ', ' . $b . ')';
if ($g < 160) {
    $textColor = '#FFF';
} else {
    $textColor = '#000';
}
$span = '<span style="background-color:' . $bgColor . '; color:' . $textColor . '; padding: 20px; font-size: 24px; display: inline-block; border-radius: 10px;">Какой-либо текст</span>';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Цветной текст</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
            padding: 50px;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="number"] {
            width: 70px;
            padding: 10px;
            margin: 5px;
            font-size: 18px;
            border: 2px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px 20px;
            font-size: 18px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .output {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <form action="" method="POST">
        <input type="number" name="r" min="0" max="255" placeholder="R" required>
        <input type="number" name="g" min="0" max="255" placeholder="G" required>
        <input type="number" name="b" min="0" max="255" placeholder="B" required>
        <br><br>
        <button type="submit">Применить</button>
    </form>
    <div class="output">
        <?php echo $span; ?>
    </div>
</body>
</html>
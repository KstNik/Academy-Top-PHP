<?php
$connect = mysqli_connect('localhost', 'vbd', 'testpassword', 'vbd');
?>
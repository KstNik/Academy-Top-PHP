<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/dist/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="all_group">
    <title>VBD221_Template</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/blog/">
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/dist/css/style.css" rel="stylesheet">
    <link href="assets/dist/css/blog.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
  </head>
  <body>
    <?php session_start();?>
    <?php include ("blocks/header.php");?>
    <main class="container">
      <?php
      require_once 'scripts/db_connect.php';
      if ($_POST['search'] != "") {
        $find = $_POST['search'];
      }
      else {
        $find = 0;
      }
      if ($find != 0) {
        $query = "SELECT * FROM `posts` WHERE `active`>0 AND (`title` LIKE '%".$find."%' OR `text` LIKE '%".$find."%')";
        $result = mysqli_query($connect,$query);
        $check = mysqli_num_rows($result);
        echo ("Результат поиска:<br><br>");
        if(empty($check)) {
          echo ("Совпадений не найдено :(");
        }
        while ($row = mysqli_fetch_assoc($result)) {
          echo ("<a href=\"post.php?id=".$row['id']."\">".$row['title']."</a><hr><br>");
        }
      }
      else {
        echo "Пустой поисковый запрос";
      }
      ?>
    </main>
    <!--footer-->
    <?php include ("blocks/footer.php");?>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
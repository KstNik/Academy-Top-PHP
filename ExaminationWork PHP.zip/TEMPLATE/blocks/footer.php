<footer class="py-5 text-center text-body-secondary bg-body-tertiary">
<div class="container" style="display: flex;justify-content: space-between;">
  <div style="display:flex;">
<img src="assets/brand/bootstrap-fill.svg" width="64">
  <ul style="margin:0;text-align:left;">
    <li><a href="#">Домашняя</a></li>
    <li><a href="#">Записи</a></li>
    <li><a href="#">Контакты</a></li>
  </ul>
  </div>
  <div>
  <p>Сведения о <a href="#">Компании</a></p>
  <a href="#"><img src="assets/brand/github.svg" width="32"></a>
  <a href="#"><img src="assets/brand/vk.svg" width="32"></a>
  </div>
  <p class="mb-0">
    <a href="#">Наверх</a>
  </p>
  </div>
</footer>
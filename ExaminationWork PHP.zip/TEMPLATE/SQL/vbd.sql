-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 10 2024 г., 15:00
-- Версия сервера: 8.3.0
-- Версия PHP: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `vbd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `active` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `user`, `pass`, `active`) VALUES
(1, 'admin001', '$2y$10$lu3MfCDOpvKCgyVz0J.d6uEveExD7vUBIwh4BVsVE5S5xptsVb22G', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `data` date NOT NULL,
  `text` varchar(1024) NOT NULL,
  `img` varchar(255) NOT NULL,
  `active` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `title`, `data`, `text`, `img`, `active`) VALUES
(1, 'Линкор «Ямато»', '2024-10-01', 'Самый мощный линкор в истории, гордость Императорского флота Японии, участвовал в последней отчаянной миссии во время Второй мировой войны.', 'Ямато.jpeg', 1),
(2, 'Линкор «Бисмарк»', '2024-10-02', 'Знаменитый немецкий линкор, потопивший флагман британского флота – линейный крейсер «Худ» и уничтоженный в ходе масштабной операции Королевского флота.', 'Бисмарк.jpg', 1),
(3, 'Танк Т-34-85', '2024-10-03', 'Самый известный советский танк, сыграл решающую роль в победе над нацистской Германией, отличался отличной бронёй и мобильностью.', 'T-34.jpg', 1),
(4, 'Танк «Тигр»', '2024-10-04', 'Немецкий тяжёлый танк, наводивший ужас на поле боя, благодаря своему мощному орудию и отличной броне.', 'Тигр.jpg', 1),
(5, 'Истребитель «Спитфайр»', '2024-10-05', 'Британский истребитель, ставший символом «Битвы за Британию», отличался высокой огневой мощью, манёвренностью и скоростью.', 'Спитфайр.jpeg', 1),
(6, 'Истребитель P-51 «Мустанг»', '2024-10-06', 'Американский истребитель, осуществлявший прикрытие дальних бомбардировщиков, отличался скоростью и дальностью полёта.', 'Мустанг.jpg', 1),
(7, 'Эрих Хартман', '2024-10-07', 'Самый результативный ас Второй мировой войны, немецкий лётчик, сбивший рекордное количество самолётов – 352.', 'Эрих_Хартман.jpeg', 1),
(8, 'Михаэль Виттман', '2024-10-08', 'Легендарный немецкий танковый ас, в боях на Восточном и Западном фронтах уничтожил 138 танков и 132 противотанковых орудия.', 'Михаэль_Виттман.jpeg', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `active` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `user`, `pass`, `active`) VALUES
(1, 'user001', '$2y$10$tXavHV9GNdUA3VWM6rQ9IOZ20cWrk17DGrViu9o2M1/G.Ko0OC1B.', 1),
(2, 'user002', '1234', 0),
(5, 'user004', '$2y$10$.5rJuO8Dp3/3mQ7.DBo/1eH63dJzTy4ZYG/yQVS9ZpyaS4R3ahDA2', 1),
(3, '[value-2]', '[value-3]', 0),
(4, 'user003', '$2y$10$3p5rnopjgkJVUvj.MOOLmeGPY1ioQ210izX8gTaNLqgsYbbaV3cj.', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

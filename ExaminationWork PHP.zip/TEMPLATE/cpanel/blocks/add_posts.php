<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Добавить запись</h1>
  </div>
  <div id="add_complete"></div>
  <form method="POST" id="add_post">
    <div class="form-row">
      <div class="form-group col-md-2">
        <label for="title">Заголовок</label>
        <input type="text" name="title" id="title" class="form-control" required>
      </div>
      <div class="form-group col-md-2">
        <label for="date">Дата</label>
        <input type="date" name="date" id="date" class="form-control" required>
      </div>
      <label for="txt">Текст записи</label>
      <textarea name="txt" id="txt" class="form-control" rows="5" cols="50" required></textarea>
      <div class="form-group col-md-2">
        <label for="cover">Изображение</label>
        <input type="file" name="cover" id="cover" class="form-control" required>
      </div>
      <br>
      <button type="submit" class="btn btn-primary">Добавить</button>
     </div>
  </form>

  <script>
    $("#add_post").submit(function() {
      let form = $("#add_post")[0];
      let formData = new FormData(form);
      $.ajax({
        url: 'scripts/post_insert.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function(data) {
          //console.log(data);
          $("#add_post")[0].reset();
          $("#add_complete").html(data);
          $("#add_complete").css("display","block");
          $("#add_complete").delay(5000).slideUp(300);
        },
        cache: false,
        contentType: false,
        processData: false
      });
      return false;
    });
  </script>

</main>
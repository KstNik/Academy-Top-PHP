<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Записи</h1>
  </div>

  <a href="index.php?p=add_posts" class="btn btn-primary">Добавить запись</a>
  <table>
     <thead>
      <tr>
       <th>Дата</th>
       <th>Заголовок</th>
       <th></th>
       <th></th>
       </tr>
    </thead>
    <tbody>
      <?php
        require_once '../scripts/db_connect.php';
        $query = "SELECT * FROM `posts` WHERE `active`>0 ORDER BY data DESC";
        $result = mysqli_query($connect, $query);
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr>";
          echo "<td>";
          echo $row['data'];
          echo "</td>";
          echo "<td>";
          echo $row['title'];
          echo "</td>";
          echo "<td>";
          /*Herdoc*/
          $here = <<<HTML
            <a href="index.php?p=edit_posts&id={$row['id']}" class="btn btn-warning btn-sm">Редактировать</a>
          HTML;
          echo $here;
          echo "</td>";

          echo "<td>";
          /*Herdoc*/
          $here = <<<HTML
            <a id="{$row['id']}" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#trash" onclick="past(this)">Удалить</a>
          HTML;
          echo $here;
          echo "</td>";

          echo "</tr>";
        }
      ?>
    </tbody>
  </table>

  <div class="modal fade" id="trash">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <div id="del_complete"></div>
          Удалить запись?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отменить</button>
          <form id="remove">
            <input type="text" id="remove_id" name="remove_id" value="" style="display:none;">
            <button type="submit" class="btn btn-danger">Удалить</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script>
    $('#remove').submit(function(){
      $.post(
          'scripts/post_delete.php',
          $('#remove').serialize(),
          function(msg) {
            $("#del_complete").html(msg);
            setTimeout(function(){
              location.reload();
            }, 2000);
            });
            return false;
          });
  </script>

  <script>
    function past(obj) {
      let id = obj.id;
      $('#remove_id').val(id);
    }
  </script>

</main>
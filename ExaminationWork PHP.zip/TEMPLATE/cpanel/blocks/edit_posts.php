<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Редактировать запись</h1>
  </div>
  <div id="edit_complete"></div>

  <?php
  require_once '../scripts/db_connect.php';
  $id = $_GET['id'];
  $query = "SELECT * FROM `posts` WHERE `id`=$id";
  $result = mysqli_query($connect,$query);
  while ($row = mysqli_fetch_assoc($result)) {
  ?>
  
  <form method="POST" id="edit_post">
    <div class="form-row">
      <input type="text" name="id" value="<?php echo $row['id']; ?>" style="display:none;">
      <div class="form-group col-md-2">
        <label for="title">Заголовок</label>
        <input type="text" name="title" id="title" class="form-control" value="<?php echo $row['title']; ?>">
      </div>
      <div class="form-group col-md-2">
        <label for="date">Дата</label>
        <input type="date" name="date" id="date" class="form-control" value="<?php echo $row['data']; ?>">
      </div>
      <label for="txt">Текст записи</label>
      <textarea name="txt" id="txt" class="form-control" rows="5" cols="50"><?php echo $row['text']; ?></textarea>
      <div class="form-group col-md-2">
        <label for="cover">Изображение</label>
        <input type="file" name="cover" id="cover" class="form-control">
      </div>
      <br>
      <button type="submit" class="btn btn-primary">Обновить</button>
     </div>
  </form>

  <?php
  }
  ?>

  <script>
    $("#edit_post").submit(function() {
      let form = $("#edit_post")[0];
      let formData = new FormData(form);
      $.ajax({
        url: 'scripts/post_update.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function(data) {
          //console.log(data);
          $("#edit_post")[0].reset();
          $("#edit_complete").html(data);
          $("#edit_complete").css("display","block");
          $("#edit_complete").delay(5000).slideUp(300);
        },
        cache: false,
        contentType: false,
        processData: false
      });
      return false;
    });
  </script>

</main>
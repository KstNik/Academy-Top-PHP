<?php
$id = $_POST['id'];
$tilte = $_POST['title'];
$date = $_POST['date'];
$text = $_POST['txt'];
$img = $_FILES['cover']['name'];
$uploadDir = "../../files/";
require_once '../../scripts/db_connect.php';
$query = "SELECT * FROM `posts` WHERE `id`=$id";
$result = mysqli_query($connect,$query);
while ($row = mysqli_fetch_assoc($result)) {
	$current_img = $row['img'];
}
if ($_FILES['cover']['name'] != "") {
	$current_img = $_FILES['cover']['name'];
	$uploadFile = $uploadDir . basename($_FILES['cover']['name']);
	move_uploaded_file($_FILES['cover']['tmp_name'], $uploadFile);
}
	$sql = "UPDATE `posts` 
	SET `title` = '{$tilte}', `data` = '{$date}', `text` = '{$text}', `img`='{$current_img}'
	WHERE `id` = '{$id}'";
	if (mysqli_query($connect, $sql)) {
		echo '<span class="badge bg-success">Запись обновлена<span>';
	}
	else {
		echo "<span>Ошибка<span>" .mysqli_error($connect);
	}
?>
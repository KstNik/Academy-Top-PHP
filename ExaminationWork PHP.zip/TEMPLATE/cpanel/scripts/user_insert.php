<?php
$login = $_POST['login'];
$passwd = $_POST['passwd'];
$hash = password_hash($passwd, PASSWORD_DEFAULT);
$validate = true;
require_once '../../scripts/db_connect.php';
$result = mysqli_query($connect, "SELECT `user` FROM `users`");
while ($row = mysqli_fetch_assoc($result)) {
	if ($row['user'] == $login) {
		$validate = false;
		break;
	}
}
if ($validate == true) {
	$sql = "INSERT INTO `users` (`user`, `pass`, `active`)
	VALUES ('{$login}', '{$hash}', 1)";
	if (mysqli_query($connect, $sql)) {
		echo '<span class="badge bg-success">Пользователь добавлен<span>';
	}
	else {
		echo "<span>Ошибка<span>" .mysqli_error($connect);
	}
}
else {
	echo '<span class="badge bg-danger">Пользователь с таким именем уже есть<span>';
}
?>
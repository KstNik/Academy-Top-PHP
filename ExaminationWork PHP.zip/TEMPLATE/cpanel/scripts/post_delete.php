<?php
$id = $_POST['remove_id'];
require_once '../../scripts/db_connect.php';
$sql = "UPDATE `posts`
SET `active` = 0
WHERE `id` = '{$id}'";
if (mysqli_query($connect, $sql)) {
	echo '<span class="badge bg-success">Запись удалена<span>';
}
else {
	echo "<span>Ошибка<span>" .mysqli_error($connect);
}
mysqli_close($connect);
?>
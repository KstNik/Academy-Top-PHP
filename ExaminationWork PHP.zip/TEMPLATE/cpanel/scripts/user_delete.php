<?php
$id = $_POST['remove_id'];
require_once '../../scripts/db_connect.php';
$result = mysqli_query($connect, "SELECT `user` FROM `users`");
$sql = "UPDATE `users`
SET `active` = 0
WHERE `id` = '{$id}'";
if (mysqli_query($connect, $sql)) {
	echo '<span class="badge bg-success">Пользователь удален<span>';
}
else {
	echo "<span>Ошибка<span>" .mysqli_error($connect);
}
mysqli_close($connect);
?>
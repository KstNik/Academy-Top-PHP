<?php
$tilte = $_POST['title'];
$date = $_POST['date'];
$text = $_POST['txt'];
$img = $_FILES['cover']['name'];
$uploadDir = "../../files/";
$check = true;
$format = array('png', 'jpg', 'jpeg', 'gif', '');
$tmp = explode('.', $img);
$type = end($tmp);
if(!in_array(strtolower($type), $format)) {
	$check = false;
}
else {
$uploadFile = $uploadDir . basename($_FILES['cover']['name']);
move_uploaded_file($_FILES['cover']['tmp_name'], $uploadFile);
}
require_once '../../scripts/db_connect.php';
if($check == true) {
	$sql = "INSERT INTO `posts` (`title`, `data`, `text`, `img`, `active`)
	VALUES ('{$tilte}', '{$date}', '{$text}', '{$img}', 1)";
	if (mysqli_query($connect, $sql)) {
		echo '<span class="badge bg-success">Запись добавлена<span>';
	}
	else {
		echo "<span>Ошибка<span>" .mysqli_error($connect);
	}
}
else {
	echo '<span class="badge bg-danger">Недопустимый формат<span>';
}
?>
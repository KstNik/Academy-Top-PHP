<?php
echo password_hash("4321", PASSWORD_DEFAULT);
?>
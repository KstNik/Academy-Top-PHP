<!doctype html>
<!-- В качестве экзаменационного задания предлагается создать веб-проект на любую интересующую вас тему. Главная задача проекта – разработать удобный интерфейс для чтения, публикации и поиска информации.
Проект должен позволять пользователю:
• Осуществлять авторизацию на портале
• Читать информацию (контент)
• Искать информацию (контент)
Проект должен иметь административную часть. Она должна позволять:
• Добавлять/удалять информацию
• Добавлять/удалять пользователей -->
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/dist/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="all_group">
    <title>VBD221_Template</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/blog/">
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/dist/css/style.css" rel="stylesheet">
    <link href="assets/dist/css/blog.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
  </head>
  <body>
    <?php session_start();?>
    <?php include ("blocks/header.php");?>
    <main class="container">
      <div class="p-4 p-md-5 mb-4 rounded text-body-emphasis bg-body-secondary">
        <div class="col-lg-6 px-0">
          <h1 class="display-4 fst-italic">Машины войны: Мощь и Сила, изменившие ход истории!</h1>
          <p class="lead my-3">Знакомьтесь с техникой и героями ей управляющими, что принесли победу на полях сражений!</p>
          <p class="lead mb-0"><a href="#" class="text-body-emphasis fw-bold">Открой для себя мощь и величие техники Второй мировой войны! Исследуй историю, узнай больше о легендарных кораблях, танках и самолётах, их роли в самых масштабных сражениях.</a></p>
        </div>
      </div>
  <div class="row">
    <div class="col-md-4">
      <h2>Корабли</h2>
      <img src="images/ships.jpg" alt="Корабли" class="img-fluid mb-3">
      <p>Морские гиганты, несущие на себе мощь артиллерийских орудий и авиации. Линкоры и тяжёлые авианосцы играли ключевую роль в обеспечении контроля над морями.</p>
    </div>
    <div class="col-md-4">
      <h2>Танки</h2>
      <img src="images/tanks.jpg" alt="Танки" class="img-fluid mb-3">
      <p>Бронированные машины, ставшие символом «Блицкрига». Танки наводили ужас на противника, изменяя исход боёв на полях сражений.</p>
    </div>
    <div class="col-md-4">
      <h2>Самолёты</h2>
      <img src="images/planes.jpg" alt="Самолёты" class="img-fluid mb-3">
      <p>Крылатые машины, участвовавшие в воздушных боях за господство в небе, осуществлявшие поддержку наземных операций и морских сражений.</p>
    </div>
  </div>
  <div class="row mt-5">
    <div class="col-md-12">
      <h2>Асы</h2>
      <img src="images/aces.jpg" alt="Асы" class="img-fluid mb-3">
      <p>Величайшие пилоты и танкисты, проявившие исключительное мастерство и героизм в сражениях. Асы Второй мировой войны олицетворяли смелость и бесстрашие как в воздушных боях, так и на земле, управляя своими машинами с потрясающей точностью. Легендарные пилоты сбивали десятки вражеских самолётов, а танкисты – изменяли исход сражений на полях битв, уничтожая вражескую технику и защищая свои позиции.</p>
    </div>
  </div>
      <div class="row g-5">
        <div class="col-md-12">
          <h3 class="pb-4 mb-4 fst-italic border-bottom">
          </h3>
          <article class="blog-post">
            <h5 class="display-6 link-body-emphasis mb-1">Обратная связь</h5>
            <p>Рекомендации по заполнению формы (при необходимости)</p>
            <form>
            <div class="mb-3 row">
              <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
              <div class="col-sm-3">
                <input type="text" class="form-control" id="staticEmail" placeholder="email@example.com">
              </div>
            </div>
            <div class="mb-3 row">
              <label for="ControlTextarea" class="col-sm-2 col-form-label">Сообщение</label>
              <div class="col-sm-3">
                  <textarea class="form-control" id="ControlTextarea" rows="3"></textarea>
              </div>
            </div>
            <button type="submit" class="btn btn-outline-primary rounded-pill">Отправить</button>
            </form>
          </article>
        </div>
      </div>
    </main>
    <!--footer-->
    <?php include ("blocks/footer.php");?>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
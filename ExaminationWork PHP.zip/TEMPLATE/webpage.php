<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/dist/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="all_group">
    <title>VBD221_Template</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/blog/">
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/dist/css/style.css" rel="stylesheet">
    <link href="assets/dist/css/blog.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
  </head>
  <body>
    <?php session_start();?>
    <?php include ("blocks/header.php");?>
    <main class="container">
      <div class="row mb-2">
        <?php
        require_once 'scripts/db_connect.php';
        $query = "SELECT * FROM `posts` WHERE `active`>0";
        $result = mysqli_query($connect,$query);
        while ($row = mysqli_fetch_assoc($result)) {
        /*HEREDOC-синтаксис*/
        $here = <<<HTML
        <div class="col-md-6">
          <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
            <div class="col p-4 d-flex flex-column position-static">
              <h3 class="mb-0">{$row['title']}</h3>
              <div class="mb-1 text-body-secondary">{$row['data']}</div>
              <p class="card-text mb-auto">{$row['text']}</p>
              <a href="#" class="icon-link gap-1 icon-link-hover stretched-link">
                Узнать больше
                <svg class="bi"><use xlink:href="#chevron-right"/></svg>
              </a>
            </div>
            <div class="col-auto d-none d-lg-block">
              <!--<img src="files/{$row['img']}" width="200" height="250">-->
              <img style="background-image:url(files/{$row['img']});background-size: cover;" width="200" height="250">
            </div>
          </div>
        </div>
        HTML;
        echo $here;
        }
        ?>
      </div>
    </main>
    <!--footer-->
    <?php include ("blocks/footer.php");?>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
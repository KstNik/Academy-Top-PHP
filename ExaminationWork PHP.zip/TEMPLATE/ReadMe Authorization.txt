Авторизация:
	администратор:
		адресная строка: localhost/TEMPLATE/cpanel/login
			login: admin001
			password: 4321
	пользователи:
		адресная строка: localhost/TEMPLATE/login
		1.	login: user001
			password: 1234
		2.	login: user003
			password: 1234
		3.	login: user004
			password: 12345
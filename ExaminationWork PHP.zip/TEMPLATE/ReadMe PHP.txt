1. Папку TEMPLATE с содержащимися в ней файлами поместить в каталог www программы Wampserver.
2. Запустить Wampserver64 (wampmanager.exe).
3. Подключить базу данных (смотри /SQL/ReadMe VBD.txt).
4. Запустить страницу index.php набрав localhost/TEMPLATE или 127.0.0.1/TEMPLATE в адресной строке браузера.
5. Авторизироваться (при необходимости) (смотри /ReadMe Authorization.txt).